/*

Assignment 1 - Program Design & Construction 2022

Coded by Mark Alexander
ID: 20112145

*/
package assignment_1;


public enum AnswerEnum {
    A,B,C,D
}
